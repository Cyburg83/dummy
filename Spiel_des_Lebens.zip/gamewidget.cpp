#include <QtWidgets>

#include "gamewidget.h"
#include <iostream>
#include <QBasicTimer>
#include <QFrame>

// Constructor
GameWidget::GameWidget(QWidget *parent)
    : QFrame(parent)
{
    setFrameStyle(QFrame::Panel | QFrame::Sunken);

}

void GameWidget::setUniverseSize()
{


}




