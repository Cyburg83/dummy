// Hier aktuelle CAbase.h einfügen!
// Auf richtige Bennenung achten, sonst gibts noch Ärger vom Übungsleiter :P (CAbase.h & gamewidget.h)
