#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

private slots:            // Erklärung: Hier kommen die Slot Funktionen rein (Slot = Empfänger eines Signals)
    void button_pressed(); // Prototyp der ersten Slot Funktion; Definition in mainwindow.cpp (nur zur Erklärung, bitte löschen!)
};

#endif // MAINWINDOW_H
