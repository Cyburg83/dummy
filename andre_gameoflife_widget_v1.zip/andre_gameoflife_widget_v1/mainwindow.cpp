#include <QTextStream>
#include <QFileDialog>
#include <QDebug>
#include <QColor>
#include <QColorDialog>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <iostream>
#include <string>
#include "gamewidget.h"

#include <QDebug> // zum testen (z.b. Ausgaben in Qt Console erzeugen)

MainWindow::MainWindow(QWidget *parent) :
QMainWindow(parent),
ui(new Ui::MainWindow),
game(new GameWidget(this))

{
    ui->setupUi(this);

    ui->mainLayout->setStretchFactor(ui->gameLayout, 8);
    ui->gameLayout->addWidget(game);

    connect(ui->pushButton_clear, SIGNAL(released()),game,SLOT(clear()));

    connect(ui->spinBox_universe_size, SIGNAL(valueChanged(int)), game, SLOT(setUniverseSize(int)));

    connect(ui->pushButton_start, SIGNAL(released()),game,SLOT(startGame()));

    connect(ui->pushButton_stop, SIGNAL(released()),game,SLOT(stopGame()));

    connect(ui->spinBox_generation_interval, SIGNAL(valueChanged(int)), game, SLOT(setTimerInterval(int)));

    connect(ui->pushButton_load, SIGNAL(released()),game,SLOT(loadFromFile()));
    connect(ui->pushButton_save, SIGNAL(released()),game,SLOT(saveToFile()));


};

MainWindow::~MainWindow()
{
    delete ui;
}
// most of these seem to be currently placeholders
void MainWindow::on_spinBox_generation_interval_valueChanged(int interval)
{
    qDebug() << interval;

}

void MainWindow::on_pushButton_start_clicked()
{
    qDebug() << "Start";
}

void MainWindow::on_pushButton_stop_clicked()
{
    qDebug() << "Stop";
}

void MainWindow::on_pushButton_clear_clicked()
{
    qDebug() << "Clear";
    game->clear();
}

void MainWindow::on_spinBox_universe_size_valueChanged(int size)
{
    qDebug() << size;
}

void MainWindow::on_pushButton_select_color_clicked()
{
    QColor color = QColorDialog::getColor(currentColor, this);
    if(!color.isValid())
        return;
    currentColor = color;
    game->setdefaultColor(color);
    QPixmap icon(16, 16);
    icon.fill(color);
    ui->pushButton_select_color->setIcon( QIcon(icon) );
}

void MainWindow::on_pushButton_random_color_clicked()
{
    QColor color = QColorDialog::getColor();
    ui->pushButton_random_color->setPalette(color);
}

void MainWindow::on_pushButton_go_clicked()
{
    qDebug() << "GO!";
}
