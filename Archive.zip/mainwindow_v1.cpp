#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <QColor>

#include <QDebug> // zum testen (z.b. Ausgaben in Qt Console erzeugen)

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // creates connection between button signals and slots
    connect(ui->pushButton_start, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_stop, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_clear, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_load, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_save, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_select_color, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_random_color, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_go, SIGNAL(released()),this,SLOT(button_pressed()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::button_pressed() // Funktionsdefinition der ersten Slot Funktion
{
    QPushButton * button = (QPushButton*)sender(); //irgendein kram mit pointern...
    qDebug() << button->text(); // ersetzt cout
}

void MainWindow::on_pushButton_select_color_clicked()
{
    QColor color = QColorDialog::getColor(Qt::black, this);
    if (color.isValid()) {
        ui->pushButton_select_color->setPalette(color);
    }
}

void MainWindow::on_pushButton_random_color_clicked()
{
    QColor color = QColorDialog::getColor();
    ui->pushButton_random_color->setPalette(color);
}
