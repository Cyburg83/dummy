#ifndef CABASE_H
#define CABASE_H


#include <iostream>

//eine neue Klasse namens CAbase
class CAbase {
public:
    //Constructor
    CAbase(int Nx,  int Ny);       //Prototyp vom Konstruktor

    // Model / View
    void showCurrent();
    void showNext();

    // Setters
    void resizeGrid(int Nx, int Ny);
    void vivifyCell(int x_coord, int y_coord);//Macht Zelle lebendig
    void evolveGrid();//Wendet Regeln auf alle Zellen an

    // Getters
    int* get_current();
    int* get_next();
    int get_size();
    int get_neighbours(int cell_x, int cell_y);



private:
    int _size_x;
    int _size_y;
    int* _current;
    int* _next;
    char* _currentView;
    char* _nextView;

    void _printGrid(char *grid, int size_x, int size_y);
    void _resizeGrid(int* &grid, char* &grid_view, int Nx, int Ny);
    void _populateCell(int* &grid, int cell);
    int _countNeighbours(int* grid, int cell, int size_x, int size_y);
    void _setCell(int* &next_grid, int* curr_grid, int cell, int neighbours);
    void _setNext(int* &grid, int size_x, int size_y);
    void _updateCurrent(int* &curr_grid, int* next_grid, int size_x, int size_y);
    void _updateView(char* &grid_view, int* grid, int Nx, int Ny);
};


#endif // CABASE_H
