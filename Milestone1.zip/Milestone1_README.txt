#########################################
		Readme - Milestone 1
#########################################

--Autoren--
Andr� Burg
Luis Hohmann
Chantal Klemm
Arvin Matic

--Einf�hrung--
Die Aufgaben eins bis drei liegen als QT Projekt in den jeweiligen Unterverzeichnissen
Aufgabe_1, Aufgabe_2, Aufgabe_3. �ber QT kann man man die Projekte �ffnen und ausf�hren.

--

