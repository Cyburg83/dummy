#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QColor>
#include "gamewidget.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


public slots:
    void selectdefaultColor();
    void selectrandomColor();
//    void saveGame();
//    void loadGame();

private:
    Ui::MainWindow *ui;
    QColor currentColor;
    GameWidget* game;

private slots:            // Erklärung: Hier kommen die Slot Funktionen rein (Slot = Empfänger eines Signals)
    void button_pressed(); // Prototyp der ersten Slot Funktion; Definition in mainwindow.cpp (nur zur Erklärung, bitte löschen!)
    void on_pushButton_random_color_clicked();
    void on_pushButton_start_clicked();
};

#endif // MAINWINDOW_H
