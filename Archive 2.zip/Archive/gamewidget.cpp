#include <QtWidgets>

#include <QMouseEvent>
#include "gamewidget.h"
#include <iostream>
#include <QFrame>
#include <QPainter>

// Constructor
GameWidget::GameWidget(QWidget *parent) :
QWidget(parent),
universeSize(50)
{

}


void GameWidget::setUniverseSize()
{

}

void GameWidget::evolve()
{
    
}

void GameWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    paintGrid(p);
    paintUniverse(p);
}

void GameWidget::paintGrid(QPainter &p)
{
    QRect sides(0, 0, width()-1, height()-1);
    QColor gridColor = m_defaultColor;
    p.setPen(gridColor);
    double cellWidth = (double)width()/universeSize;
    for(double k = cellWidth; k <= width(); k += cellWidth)
        p.drawLine(k, 0, k, height());
    double cellHeight = (double)height()/universeSize;
    for(double k = cellHeight; k <= height(); k += cellHeight)
        p.drawLine(0, k, width(), k);
    p.drawRect(sides);
}

void GameWidget::paintUniverse(QPainter &p)
{

}

int GameWidget::interval()
{
    return timer->interval();
}

void GameWidget::setInterval(int msec)
{
    timer->setInterval(msec);
}

QColor GameWidget::defaultColor()
{
    return m_defaultColor;
}

void GameWidget::setdefaultColor(const QColor &color)
{
    m_defaultColor = color;
    update();
}
