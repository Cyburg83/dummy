#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QFrame>
#include <QPointer>
#include <QColor>
#include <QFileDialog>


#include "CAbase.h"

class GameWidget : public QWidget
{
    Q_OBJECT

public:
    GameWidget(QWidget *parent = 0);

protected:
    void paintEvent(QPaintEvent *);
//    void mousePressEvent(QMouseEvent *event) override;
//    void mouseMoveEvent(QMouseEvent *event) override;

//    void paintUniverse(QPaintEvent *event);
//    void timerEvent(QTimerEvent *event) override;


public slots:

    int interval(); // interval between generations
    void setInterval(int msec); // sets interval
    
    QColor defaultColor(); // cell color
    void setdefaultColor(const QColor &color);
    

private:
    void setUniverseSize(); //resize
    void evolve();

    bool* universe; // map
    int universeSize;
    QTimer* timer;

    QColor m_defaultColor;
    bool* next; // map


private slots:
    void paintUniverse(QPainter &p);
    void paintGrid(QPainter &p);

};


#endif // GAMEWIDGET_H

