#include <QColor>
#include <QColorDialog>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <iostream>

#include <QDebug> // zum testen (z.b. Ausgaben in Qt Console erzeugen)

MainWindow::MainWindow(QWidget *parent) :
QMainWindow(parent),
ui(new Ui::MainWindow),
game(new GameWidget(this))

{
    ui->setupUi(this);
    
    QPixmap icon(16, 16);
    icon.fill(currentColor);
    
    // creates connection between button signals and slots
    connect(ui->pushButton_start, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_stop, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_clear, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_load, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_save, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_select_color, SIGNAL(clicked()),this,SLOT(selectdefaultColor()));
    connect(ui->pushButton_random_color, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->pushButton_go, SIGNAL(released()),this,SLOT(button_pressed()));
    connect(ui->spinBox_universe_size, SIGNAL(valueChanged(int)), game, SLOT(setCellNumber(int)));
    connect(ui->spinBox_generation_interval, SIGNAL(valueChanged(int)), game, SLOT(setInterval(int)));

    ui->Main->setStretchFactor(ui->Board, 8);
    ui->Board->addWidget(game);
};

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::button_pressed() // Funktionsdefinition der ersten Slot Funktion
{
    QPushButton * button = (QPushButton*)sender(); //irgendein kram mit pointern...
    qDebug() << button->text(); // ersetzt cout
}

void MainWindow::on_pushButton_random_color_clicked()
{
    QColor color = QColorDialog::getColor();
    ui->pushButton_random_color->setPalette(color);
}

void MainWindow::on_pushButton_start_clicked()
{
    CAbase start(10, 10); //hab nur getestet, ob es so funktioniert
    
}

void MainWindow::selectdefaultColor()
{
    QColor color = QColorDialog::getColor(currentColor, this);
    if(!color.isValid())
        return;
    currentColor = color;
    game->setdefaultColor(color);
    QPixmap icon(16, 16);
    icon.fill(color);
    ui->pushButton_select_color->setIcon( QIcon(icon) );
}

void MainWindow::selectrandomColor()
{
    
}
