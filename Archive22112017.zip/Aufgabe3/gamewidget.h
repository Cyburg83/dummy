#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QTimer>
#include <QFrame>
#include <QPointer>
#include <QColor>
#include <QFileDialog>
#include <QGraphicsScene>
#include <QFile>
#include <QDataStream>


class CAbase;

class GameWidget : public QWidget
{
    Q_OBJECT

public:
    GameWidget(QWidget *parent = 0);

public slots:
    void saveToFile();
    void loadFromFile();

    void startGame();
    void stopGame();
    void clear();

    void newGeneration();

    void setTimerInterval(int interval);

    void setUniverseSize(int newSize);

    QColor defaultColor(); // cell color
    void setdefaultColor(const QColor &color);

    int getUniverseSize();


protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void paintEvent(QPaintEvent *);


private slots:
    void paintGrid(QPainter &p, QRect &rect, int gridWidth, int gridHeight, int cellWidth, int cellHeight);
    void paintCell(const QPoint &lastCell);
    void paintUniverse(QPainter &p, CAbase *cabase);

private:
    int universeSize;
    CAbase *ca1;
    QColor m_defaultColor;
    QTimer *timer;

    int cellWidth;
    int cellHeight;

    int gridWidth;
    int gridHeight;

    bool drawing;

    bool modified;
    QPoint currentCell;

};


#endif // GAMEWIDGET_H

